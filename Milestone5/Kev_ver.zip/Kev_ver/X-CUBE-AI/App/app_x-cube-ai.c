
/**
  ******************************************************************************
  * @file    app_x-cube-ai.c
  * @author  X-CUBE-AI C code generator
  * @brief   AI program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

 /*
  * Description
  *   v1.0 - Minimum template to show how to use the Embedded Client API
  *          model. Only one input and one output is supported. All
  *          memory resources are allocated statically (AI_NETWORK_XX, defines
  *          are used).
  *          Re-target of the printf function is out-of-scope.
  *   v2.0 - add multiple IO and/or multiple heap support
  *
  *   For more information, see the embeded documentation:
  *
  *       [1] %X_CUBE_AI_DIR%/Documentation/index.html
  *
  *   X_CUBE_AI_DIR indicates the location where the X-CUBE-AI pack is installed
  *   typical : C:\Users\<user_name>\STM32Cube\Repository\STMicroelectronics\X-CUBE-AI\7.1.0
  */

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#if defined ( __ICCARM__ )
#elif defined ( __CC_ARM ) || ( __GNUC__ )
#endif

/* System headers */
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
#include <string.h>
#include "data.h"

#include "app_x-cube-ai.h"
#include "main.h"
#include "ai_datatypes_defines.h"
#include "network.h"
#include "network_data.h"

/* USER CODE BEGIN includes */
/* USER CODE END includes */

/* IO buffers ----------------------------------------------------------------*/

#if !defined(AI_NETWORK_INPUTS_IN_ACTIVATIONS)
AI_ALIGNED(4) ai_i8 data_in_1[AI_NETWORK_IN_1_SIZE_BYTES];
ai_i8* data_ins[AI_NETWORK_IN_NUM] = {
data_in_1
};
#else
ai_i8* data_ins[AI_NETWORK_IN_NUM] = {
NULL
};
#endif

#if !defined(AI_NETWORK_OUTPUTS_IN_ACTIVATIONS)
AI_ALIGNED(4) ai_i8 data_out_1[AI_NETWORK_OUT_1_SIZE_BYTES];
ai_i8* data_outs[AI_NETWORK_OUT_NUM] = {
data_out_1
};
#else
ai_i8* data_outs[AI_NETWORK_OUT_NUM] = {
};
#endif

/* Activations buffers -------------------------------------------------------*/

AI_ALIGNED(32)
static uint8_t pool0[AI_NETWORK_DATA_ACTIVATION_1_SIZE];

ai_handle data_activations0[] = {pool0};

/* AI objects ----------------------------------------------------------------*/

static ai_handle network = AI_HANDLE_NULL;

static ai_buffer* ai_input;
static ai_buffer* ai_output;

int res = 0;
float predictionval[10];
AI_ALIGNED(4)
static ai_i8 in_data[AI_NETWORK_IN_1_SIZE_BYTES];
AI_ALIGNED(4)
static ai_i8 out_data[AI_NETWORK_OUT_1_SIZE_BYTES];
class_name_index[10];
static void ai_log_err(const ai_error err, const char *fct)
{
  /* USER CODE BEGIN log */
  if (fct)
    printf("TEMPLATE - Error (%s) - type=0x%02x code=0x%02x\r\n", fct,
        err.type, err.code);
  else
    printf("TEMPLATE - Error - type=0x%02x code=0x%02x\r\n", err.type, err.code);

  do {} while (1);
  /* USER CODE END log */
}

static int ai_boostrap(ai_handle *act_addr)
{
  ai_error err;

  /* Create and initialize an instance of the model */
  err = ai_network_create_and_init(&network, act_addr, NULL);
  if (err.type != AI_ERROR_NONE) {
    ai_log_err(err, "ai_network_create_and_init");
    return -1;
  }

  ai_input = ai_network_inputs_get(network, NULL);
  ai_output = ai_network_outputs_get(network, NULL);

#if defined(AI_NETWORK_INPUTS_IN_ACTIVATIONS)
  /*  In the case where "--allocate-inputs" option is used, memory buffer can be
   *  used from the activations buffer. This is not mandatory.
   */
  for (int idx=0; idx < AI_NETWORK_IN_NUM; idx++) {
	data_ins[idx] = ai_input[idx].data;
  }
#else
  for (int idx=0; idx < AI_NETWORK_IN_NUM; idx++) {
	  ai_input[idx].data = data_ins[idx];
  }
#endif

#if defined(AI_NETWORK_OUTPUTS_IN_ACTIVATIONS)
  /*  In the case where "--allocate-outputs" option is used, memory buffer can be
   *  used from the activations buffer. This is no mandatory.
   */
  for (int idx=0; idx < AI_NETWORK_OUT_NUM; idx++) {
	data_outs[idx] = ai_output[idx].data;
  }
#else
  for (int idx=0; idx < AI_NETWORK_OUT_NUM; idx++) {
	ai_output[idx].data = data_outs[idx];
  }
#endif

  return 0;
}

int aiRun(const int *in_data, int *out_data)
{
    ai_i32 nbatch;
    ai_error err;

    /* Parameters checking */
    if (!in_data || !out_data || !network)
        return -1;

    /* Initialize input/output buffer handlers */
    ai_input[0].n_batches = 1;
    ai_input[0].data = AI_HANDLE_PTR(in_data);
    ai_output[0].n_batches = 1;
    ai_output[0].data = AI_HANDLE_PTR(out_data);

    /* 2 - Perform the inference */
    nbatch = ai_network_run(network, &ai_input[0], &ai_output[0]);
    if (nbatch != 1) {
        err = ai_network_get_error(network);
        // ...
        return err.code;
    }

    return 0;
}

/* USER CODE BEGIN 2 */
int acquire_and_process_data(ai_i8* data[])
{
  /* fill the inputs of the c-model
  for (int idx=0; idx < AI_NETWORK_IN_NUM; idx++ )
  {
      data[idx] = ....
  }

  */
  return 0;
}

void post_process(int val)
{
	uint32_t u32dummy;
		uint16_t i,j,x=0;
		float dummyfloat;
		uint8_t lcdbfr[128];
	if(!res){
			  //BSP_LCD_DisplayStringAt(2, 80+WINDOWS_HEIGHT, (uint8_t*)"PREDICTION:",LEFT_MODE);

				for(i=0;i<10;i++){
					uint8_t* p = (uint8_t*)(void*)&dummyfloat;
					u32dummy = (uint8_t)out_data[x+3];
					u32dummy = (u32dummy << 8)|(uint8_t)out_data[x+2];
					u32dummy = (u32dummy << 8)|(uint8_t)out_data[x+1];
					u32dummy = (u32dummy << 8)|(uint8_t)out_data[x];
					x+=4;
					for(j=0;j<4;j++){
						p[j]=u32dummy >> (8*j);
					}
			       predictionval[i]=dummyfloat*100;

				}

				Bubblesort();
				//x=80+WINDOWS_HEIGHT+15;
				if(predictionval[1] == 1){

					val = 1;
				}
				else if(predictionval[2] == 1){
					val =2;
				}
				else{
					val =0;
				}
				//for(i=9;i>=7;i--){
					//sprintf((char*)lcdbfr,"DIGIT %s (%.2f%%)  ",digit_label[class_name_index[9]],predictionval[9]);
					//BSP_LCD_DisplayStringAt(2, x, (uint8_t*)lcdbfr,LEFT_MODE);
					//x+=15;
				//}


		  }
}
/* USER CODE END 2 */

/* Entry points --------------------------------------------------------------*/

void MX_X_CUBE_AI_Init(void)
{
    /* USER CODE BEGIN 5 */
  printf("\r\nTEMPLATE - initialization\r\n");

  ai_boostrap(data_activations0);
    /* USER CODE END 5 */
}

int MX_X_CUBE_AI_Process()
{
    /* USER CODE BEGIN 6 */


  printf("TEMPLATE - run - main loop\r\n");
  int val;
  if (network) {
     if (res == 0){
    	  uint16_t i,x,j;

    	  	x=0;
    	  	for(i=0;i<784;i++){
    	  		uint8_t* bfr=(uint8_t*)(void*)&Indata_2[i];
    	  	   	for(j=0;j<4;j++){
    	  	   		//x++;
    	  	   		in_data[x++]=bfr[j];
    	  	   	}
    	  	}
    	  // input data
    	  	res = aiRun(in_data,out_data);
    	  	post_process(val);
      }

    }

  if (res) {
    ai_error err = {AI_ERROR_INVALID_STATE, AI_ERROR_CODE_NETWORK};
    ai_log_err(err, "Process has FAILED");
  }
  if(val == 1){
	  return 1;
  }
  else if(val == 2){
	  return 2;
  }
  else{
	  return 0;
  }

    /* USER CODE END 6 */
}

static void Bubblesort(void){
	int total_count, counter, counter1,swap_rank;
	float swap_var;
	 total_count=10;

	 for(counter=0;counter<10;counter++){
		 class_name_index[counter]= counter;
	 }

	for (counter = 0 ; counter < total_count - 1; counter++){
		for (counter1 = 0 ; counter1 < total_count - counter - 1; counter1++){
			if(predictionval[counter1]>predictionval[ counter1+1]){
				swap_var = predictionval[counter1];
				predictionval[counter1]=predictionval[counter1+1];
				predictionval[counter1+1]=swap_var;

				swap_rank = class_name_index[counter1];
				class_name_index[counter1]=class_name_index[counter1+1];
				class_name_index[counter1+1]=swap_rank;
			}
		}
	}

}

#ifdef __cplusplus
}
#endif
